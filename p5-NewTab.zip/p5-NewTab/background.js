chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.sync.get(null, (values) => {
    chrome.storage.sync.set({
      html: ``,
      css: `html, body {
        margin: 0;
        padding: 0;
      }
      canvas {
        display: block;
      }
      `,
      js: 
`
// this is p5`,
      ...values
    });
  });
});

chrome.browserAction.onClicked.addListener(function() {
	window.open("options.html");
});
