// put your p5 code here!

function setup() {
    createCanvas(windowWidth, windowHeight);
    background(150);
}

function draw() {
    textSize(50)
    text("Anna", mouseX, mouseY)
}

function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}