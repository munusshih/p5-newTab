chrome.storage.sync.get(["html", "css", "js"], function (data) {
	const htmlCM = CodeMirror(document.querySelector("#html"), {
		value: data.html,
		mode: "htmlmixed",
		theme: "dracula",
		lineNumbers: true,
		autoCloseBrackets: true,
		matchBrackets: true,
		autoCloseTags: true,
		matchTags: { bothTags: true }
	});

	const cssCM = CodeMirror(document.querySelector("#css"), {
		value: data.css,
		mode:  "css",
		theme: "dracula",
		lineNumbers: true,
		autoCloseBrackets: true,
		matchBrackets: true
	});

	const jsCM = CodeMirror(document.querySelector("#js"), {
		value: data.js,
		mode:  "javascript",
		theme: "dracula",
		lineNumbers: true,
		autoCloseBrackets: true,
		matchBrackets: true
	});

	function selectTab(tab) {
		document.querySelectorAll("#html, #css, #js").forEach(elem => {
			elem.style.display = "none";
		});

		document.querySelector(`#${tab}`).style.display = "block";

		document.querySelectorAll("#html-btn, #css-btn, #js-btn").forEach(elem => {
			elem.classList.remove("panel__tab--selected");
		});
		document.querySelector(`#${tab}-btn`).classList.add("panel__tab--selected");

		htmlCM.refresh();
		cssCM.refresh();
		jsCM.refresh();
	}

	selectTab("html");

	document.querySelector("#html-btn").addEventListener("click", function() {
		selectTab("html");
	});
	document.querySelector("#css-btn").addEventListener("click", function() {
		selectTab("css");
	});
	document.querySelector("#js-btn").addEventListener("click", function() {
		selectTab("js");
	});

	chrome.storage.onChanged.addListener(function(changes) {
		if ("html" in changes) {
			if (changes.html.newValue !== htmlCM.getValue()) {
				htmlCM.setValue(changes.html.newValue);
			}
		}
		if ("css" in changes) {
			if (changes.css.newValue !== cssCM.getValue()) {
				cssCM.setValue(changes.css.newValue);
			}
		}
		if ("js" in changes) {
			if (changes.js.newValue !== jsCM.getValue()) {
				jsCM.setValue(changes.js.newValue);
			}
		}
	});

	function save() {
		chrome.storage.sync.set({
			html: htmlCM.getValue(),
			css: cssCM.getValue(),
			js: jsCM.getValue()
		});
	}

	document.addEventListener("keydown", function(e) {
		if ((window.navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)  && e.keyCode == 83) {
			e.preventDefault();
			save();
		}
	});


	document.querySelector("#save").addEventListener("click", function() {
		save();
	});
});
