chrome.storage.sync.get(["html", "css", "js"], function (data) {
	document.querySelector("#__replaceWithUserHTML__").outerHTML = data.html;

	const cssURL = URL.createObjectURL(new Blob([data.css], {
		type: "text/css"
	}));
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.href = cssURL;
	document.head.appendChild(link);

	const jsURL = URL.createObjectURL(new Blob([data.js], {
		type: "text/javascript"
	}));

	const script = document.createElement("script");
	script.src = jsURL;
	document.body.appendChild(script);
});

chrome.storage.onChanged.addListener(function () {
	location.reload();
});